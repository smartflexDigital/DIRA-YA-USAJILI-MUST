#!/usr/bin/env bash
set -euo pipefail

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$SDK" ]]; then
  echo "ANDROID_HOME or ANDROID_SDK_ROOT is required" >&2
  exit 1
fi

PLATFORM="android-35"
TOOLS="$SDK/build-tools/35.0.0"
ANDROID_JAR="$SDK/platforms/$PLATFORM/android.jar"
for file in "$TOOLS/aapt" "$TOOLS/d8" "$TOOLS/zipalign" "$TOOLS/apksigner" "$ANDROID_JAR"; do
  if [[ ! -f "$file" ]]; then
    echo "Missing Android build file: $file" >&2
    exit 1
  fi
done

BUILD="$(pwd)/build"
mkdir -p "$BUILD/classes" "$BUILD/dex" dist
rm -f "$BUILD/base.apk" "$BUILD/aligned.apk" "$BUILD/classes.jar" "$BUILD/dex/classes.dex" dist/Msaidizi-MUST.apk

"$TOOLS/aapt" package -f -M AndroidManifest.xml -I "$ANDROID_JAR" -F "$BUILD/base.apk"
javac -source 8 -target 8 -bootclasspath "$ANDROID_JAR" -d "$BUILD/classes" MainActivity.java
jar cf "$BUILD/classes.jar" -C "$BUILD/classes" .
"$TOOLS/d8" --min-api 23 --lib "$ANDROID_JAR" --output "$BUILD/dex" "$BUILD/classes.jar"
(cd "$BUILD/dex" && "$TOOLS/aapt" add "$BUILD/base.apk" classes.dex)
"$TOOLS/zipalign" -f 4 "$BUILD/base.apk" "$BUILD/aligned.apk"

# This key is for this downloadable sideload build. Never commit the keystore.
keytool -genkeypair -noprompt -keystore "$BUILD/must-release.p12" -storetype PKCS12 \
  -storepass android -keypass android -alias must-apk -keyalg RSA -keysize 2048 \
  -validity 10000 -dname "CN=Msaidizi wa MUST, OU=Mobile, O=SmartflexDigital, C=TZ"
"$TOOLS/apksigner" sign --ks "$BUILD/must-release.p12" --ks-pass pass:android \
  --key-pass pass:android --out dist/Msaidizi-MUST.apk "$BUILD/aligned.apk"
"$TOOLS/apksigner" verify --verbose dist/Msaidizi-MUST.apk
echo "APK created at $(pwd)/dist/Msaidizi-MUST.apk"
